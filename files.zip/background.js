// FocusBill - Background Service Worker
// ======================================

let blockingEnabled = false;
let blockedSites = [];

// Load blocking state from storage on startup
chrome.storage.local.get(['blockingState'], (result) => {
  if (result.blockingState) {
    blockingEnabled = result.blockingState.enabled || false;
    blockedSites = result.blockingState.sites || [];
    console.log('Restored blocking state:', { blockingEnabled, blockedSites });
  }
});

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'startBlocking') {
    blockingEnabled = true;
    blockedSites = request.sites || [];
    
    // Save blocking state
    chrome.storage.local.set({
      blockingState: { enabled: true, sites: blockedSites }
    });
    
    console.log('🚫 Blocking enabled for sites:', blockedSites);
    sendResponse({ success: true });
  } else if (request.action === 'stopBlocking') {
    blockingEnabled = false;
    blockedSites = [];
    
    // Clear blocking state
    chrome.storage.local.set({
      blockingState: { enabled: false, sites: [] }
    });
    
    console.log('✅ Blocking disabled');
    sendResponse({ success: true });
  } else if (request.action === 'ping') {
    sendResponse({ status: 'alive', blockingEnabled, blockedSites });
  }
  
  return true;
});

// Intercept navigation requests
chrome.webNavigation.onBeforeNavigate.addListener((details) => {
  if (!blockingEnabled || details.frameId !== 0) return;

  try {
    const url = new URL(details.url);
    const hostname = url.hostname.replace(/^www\./, '');

    // Check if site is blocked
    const isBlocked = blockedSites.some(site => {
      const cleanSite = site.replace(/^www\./, '');
      // Check exact match, subdomain match, or partial match
      return hostname === cleanSite || 
             hostname.endsWith('.' + cleanSite) || 
             cleanSite.endsWith('.' + hostname) ||
             hostname.includes(cleanSite) ||
             cleanSite.includes(hostname);
    });

    if (isBlocked) {
      console.log('🚫 BLOCKED navigation to:', hostname, 'from:', details.url);
      // Redirect to blocking page
      chrome.tabs.update(details.tabId, {
        url: chrome.runtime.getURL('blocked.html')
      });
    } else {
      console.log('✅ Allowed:', hostname);
    }
  } catch (e) {
    console.error('❌ Error in onBeforeNavigate:', e);
  }
});

// Handle tab updates (for when user is already on a blocked site)
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (!blockingEnabled || !changeInfo.url) return;

  try {
    const url = new URL(changeInfo.url);
    const hostname = url.hostname.replace(/^www\./, '');

    const isBlocked = blockedSites.some(site => {
      const cleanSite = site.replace(/^www\./, '');
      return hostname === cleanSite || 
             hostname.endsWith('.' + cleanSite) || 
             cleanSite.endsWith('.' + hostname) ||
             hostname.includes(cleanSite) ||
             cleanSite.includes(hostname);
    });

    if (isBlocked) {
      console.log('🚫 BLOCKED tab update to:', hostname);
      chrome.tabs.update(tabId, {
        url: chrome.runtime.getURL('blocked.html')
      });
    }
  } catch (e) {
    // Invalid URL, ignore
    console.error('❌ Error in onUpdated:', e);
  }
});

// Set up alarms for timer notifications
chrome.alarms.create('checkTimer', { periodInMinutes: 1 });

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'checkTimer') {
    // Check if timer should trigger notification
    // This will be synced with popup state
  }
});

// Keep service worker alive
setInterval(() => {
  console.log('Service worker heartbeat');
}, 20000);

console.log('FocusBill background service worker loaded');
